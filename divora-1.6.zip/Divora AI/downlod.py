# @title Download Model
# Download model
import zipfile
import os

def zip_folder(folder_path, output_filename):
    with zipfile.ZipFile(output_filename,'w') as zipf:
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                zipf.write(os.path.join(root, file))


# Path to the folder you want to zip
folder_to_zip = "/Divora AI/models/124M"

# Output zip file name
output_zip_filename = "model.zip"

zip_folder(folder_to_zip, output_zip_filename)
