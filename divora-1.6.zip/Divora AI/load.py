#python3 -m pip install divora
import tensorflow.compat.v1 as tf
tf.disable_v2_behavior()
import divora as dv

model_name = "run1"
checkpoint_dir = "checkpoint"  

tf.reset_default_graph()
sess = dv.start_tf_sess()

dv.load_dv(sess, model_name=model_name, checkpoint_dir=checkpoint_dir)

while True:
    user_input = input("You: ")

    generated_text = dv.generate(
        sess,
        model_name=model_name,
        checkpoint_dir=checkpoint_dir,
        prefix=user_input,
        nsamples=1,
        batch_size=1,
        length=100,
        temperature=0.7,
        return_as_list=True
    )[0]


    first_period_index = generated_text.find('.')
    if first_period_index != -1:
        generated_text = generated_text[:first_period_index + 1]


    print("AI:", generated_text)
