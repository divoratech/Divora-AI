#python3 -m pip install divora
import os
import divora as dv
model_name = "124M"
if not os.path.isdir(os.path.join("models", model_name)):
    print(f"Downloading {model_name} model...")
    dv.download_dv(model_name=model_name)

file_path = input("Enter the path of the training file: ")

if not os.path.isfile(file_path):
    print(f"File '{file_path}' not found.")
else:
    sess = dv.start_tf_sess()
    dv.finetune(sess,
                  file_path,
                  model_name=model_name,
                  steps=1000)
    dv.generate(sess)