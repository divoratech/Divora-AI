## License

MIT

## Disclaimer

This repo has no affiliation or relationship with OpenAI.
